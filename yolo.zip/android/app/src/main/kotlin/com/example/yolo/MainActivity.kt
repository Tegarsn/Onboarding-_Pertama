package com.example.yolo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
